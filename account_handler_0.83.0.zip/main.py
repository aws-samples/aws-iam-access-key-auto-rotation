import codecs
import csv
import json
import os

from boto3 import client, resource

s3 = resource('s3')
dynamodb = resource('dynamodb')

bucket = os.environ['S3_BUCKET']
key = os.environ['S3_KEY']
table_name = os.environ['DYNAMODB_TABLE_NAME']


def lambda_handler(event, context):

    obj = s3.Object(bucket, key).get()['Body']

    for row in csv.DictReader(codecs.getreader('utf-8-sig')(obj)):
        account_id = row['accountid']
        account_name = row['accountname']
        account_email = row['accountemail']
        account_owner = row['accountowner']

        write_to_dynamo(account_id, account_name, account_email, account_owner)

    return {
        'statusCode': 200,
        'body': json.dumps('Uploaded to DynamoDB Table')
    }


def write_to_dynamo(account_id, account_name, email, owner):
    dynamodb_client = client('dynamodb')

    dynamodb_client.put_item(
        TableName=table_name,
        Item={
            'uuid': {
                'S': account_id
            },
            'accountid': {
                'S': account_id
            },
            'accountname': {
                'S': account_name
            },
            'accountemail': {
                'S': email
            },
            'accountowner': {
                'S': owner
            }
        }
    )
