"""Version.

Contains the application version number. This file is managed by
bump2version. Do not edit manually.
"""


__version__ = '0.83.0'
