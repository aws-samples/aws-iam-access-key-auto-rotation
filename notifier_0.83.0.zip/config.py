"""Config.

Provides configuration for the application.
"""

import os
from dataclasses import dataclass, field
from typing import Dict

try:
    from __version__ import __version__
except ImportError:
    from .__version__ import __version__


@dataclass
class Config:
    version: str = __version__
    admin_email: str = os.getenv('ADMIN_EMAIL')
    dynamodb_table_name: str = os.getenv('DYNAMODB_TABLE_NAME')
    s3_bucket_name = os.getenv('S3_BUCKET_NAME')
    s3_bucket_prefix = os.getenv('S3_BUCKET_PREFIX')
    templates: Dict = field(
        default_factory=lambda: {
            'New AWS IAM Access Key Pair Created': 'iam-auto-key-rotation-enforcement.html'
        }
    )
