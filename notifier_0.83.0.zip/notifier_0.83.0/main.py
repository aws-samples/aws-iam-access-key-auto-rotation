"""Main.py.

This is the main entry point for this application.
"""

import json
import logging

from config import Config
from notifier import Notifier

log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


def lambda_handler(event: dict = None, context=None):
    """Lambda Handler."""

    config = Config()

    log.info(f'App Version: {config.version}')
    log.info(f'Event: {json.dumps(event, indent=2)}')

    for record in event.get('Records'):
        notifier = Notifier(config, record)
        notifier.send_email()
