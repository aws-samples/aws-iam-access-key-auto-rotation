"""Notifier.

Provies core logic for the Notifier Lambda Function.
"""

import logging
import boto3

from botocore.exceptions import ClientError

from config import Config
from dynamodb import DynamoDBClient


log = logging.getLogger(__name__)
log.setLevel(logging.INFO)


class Notifier:
    def __init__(self, config: Config, record: dict) -> None:
        self.config = config
        self.record = record

    @staticmethod
    def __parse_arn(arn):
        # http://docs.aws.amazon.com/general/latest/gr/aws-arns-and-namespaces.html
        elements = arn.split(':', 5)
        result = {
            'arn': elements[0],
            'partition': elements[1],
            'service': elements[2],
            'region': elements[3],
            'account': elements[4],
            'resource': elements[5],
            'resource_type': None
        }
        if '/' in result['resource']:
            result['resource_type'], result['resource'] = result['resource'].split('/', 1)  # NOQA
        elif ':' in result['resource']:
            result['resource_type'], result['resource'] = result['resource'].split(':', 1)  # NOQA
        return result

    def __get_record_details(self, record):
        log.info('Getting record details')
        subject = record.get('Sns')['Message']['detail']['eventName']
        message = record.get('Sns')['Message']
        arn = self.record.get('EventSubscriptionArn')
        arn_elements = self.__parse_arn(arn)

        account_id = arn_elements.get('account')

        return (account_id, subject, message)

    def __get_template_name(self, subject):
        log.info('Getting template name')
        templates = self.config.templates

        if subject in templates:
            template_name = templates.get(subject)
            log.info(f'Template found - {template_name}')
            return template_name
        else:
            return ''

    def __get_template(self, template_name):
        log.info(f'Getting template {template_name} from S3')
        s3 = boto3.client('s3')

        try:
            obj = s3.get_object(
                Bucket=self.config.s3_bucket_name,
                Key=f'{self.config.s3_bucket_prefix}/template/{template_name}'
            )
            data = obj['Body'].read()
            template = data.decode('utf-8')
            log.info(f'Successfully retrieved content for {template_name}')
            return template
        except ClientError as err:
            log.error(
                f'Error while getting file contents for {template_name} - {err}'
            )

    def __render_email_body(self, subject, message):

        # Get the appropriate S3 Key for the template
        template_s3_key = self.__get_template_name(subject)
        if not template_s3_key:
            log.error(f'Unable to get template for {subject}')
            raise ValueError(f'Unable to get template for {subject}')
        else:
            # Stream the template contents from S3
            email = self.__get_template(template_s3_key)

            log.info('Rendering email contents')
            replace_values = {
                '[insert-violations-here]': message,
                'EMAIL ADDRESS HERE': self.config.admin_email
            }

            for k, v in replace_values.items():
                email = email.replace(k, v)

            log.info(f'Rendered Email: {email}')

            return email

    def __get_recipient_email(self, account_id):
        ddb = DynamoDBClient(self.config.dynamodb_table_name, 'uuid')
        try:
            log.info(f'Getting recipient email address')
            resp = ddb.get_item(account_id)

            item = resp.get('Item')

            log.info(f'DDB Response: {resp}')
            recipient_email = item.get('accountemail')
            log.info(f'Recipient Email {recipient_email}')
            return recipient_email
        except ClientError as err:
            log.error(
                f'Encountered error while getting recipient email - {err}'
            )
            raise err

    def send_email(self):
        ses = boto3.client('ses')
        account_id, subject, message = self.__get_record_details(self.record)
        email_body = self.__render_email_body(subject, message)
        recipient_email = self.__get_recipient_email(account_id)

        try:
            log.info(f'Sending email to {recipient_email}')
            resp = ses.send_email(
                Source=self.config.admin_email,
                Destination={
                    'ToAddresses': [
                        recipient_email,
                    ]
                },
                Message={
                    'Subject': {
                        'Data': subject
                    },
                    'Body': {
                        'Text': {
                            'Data': email_body
                        },
                        'Html': {
                            'Data': email_body
                        }
                    }
                }
            )
            log.info('Email sent successfully - Exiting Gracefully')
            return resp
        except ClientError as err:
            log.error(
                f'Encountered error while attempting to send email - {err}'
            )
            raise err
